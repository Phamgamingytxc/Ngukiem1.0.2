# Changelog

## 1.0.0
- Bản đầu: menu `/tutien`, ngự kiếm `/kiem`, xuất hồn `/xuathon` + `/thuhon`, quét sinh linh `/thanthuc`, quản lý cảnh giới `/canhgioi`.
- Sửa `/canhgioi <player> <1-9>` từ console và chặn cú pháp sai.
- Hồn thể giữ nguyên vị trí thân xác khi xuất hồn.
- Thu hồn khôi phục đúng trạng thái trước đó (tàng hình, bất tử, va chạm, quyền bay).
- Bỏ tự quét thần thức lặp mỗi giây gây spam thông báo.
