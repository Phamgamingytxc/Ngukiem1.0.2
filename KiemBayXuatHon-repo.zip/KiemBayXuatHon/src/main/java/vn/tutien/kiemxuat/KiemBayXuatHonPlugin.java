package vn.tutien.kiemxuat;

import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.*;

public final class KiemBayXuatHonPlugin extends JavaPlugin implements Listener, CommandExecutor, TabCompleter {
    private final Map<UUID, SoulState> souls = new HashMap<>();
    private final Map<UUID, Long> lastScan = new HashMap<>();
    private final Map<UUID, Long> lastFlightToggle = new HashMap<>();
    private NamespacedKey realmKey;
    private static final String MENU_TITLE = ChatColor.DARK_AQUA + "Tu Tiên • Thần Thông";

    private record SoulState(Location body, ArmorStand avatar, long expiresAt, double maxDistance,
                             boolean wasInvisible, boolean wasInvulnerable, boolean wasCollidable,
                             boolean wasAllowFlight, boolean wasFlying) {}

    @Override public void onEnable() {
        saveDefaultConfig();
        realmKey = new NamespacedKey(this, "realm");
        for (String cmd : List.of("tutien", "kiem", "xuathon", "thuhon", "thanthuc", "canhgioi")) {
            Objects.requireNonNull(getCommand(cmd), "Missing command " + cmd).setExecutor(this);
            getCommand(cmd).setTabCompleter(this);
        }
        getServer().getPluginManager().registerEvents(this, this);
        new BukkitRunnable() { @Override public void run() { tickSouls(); } }.runTaskTimer(this, 1L, 2L);
        getLogger().info("KiemBayXuatHon enabled.");
    }

    @Override public void onDisable() {
        for (UUID id : new ArrayList<>(souls.keySet())) returnSoul(Bukkit.getPlayer(id), false);
        for (Player p : Bukkit.getOnlinePlayers()) if (p.isFlying()) p.setFlying(false);
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            if (command.getName().equalsIgnoreCase("canhgioi") && args.length == 2 && sender.hasPermission("kiemxuat.admin")) {
                Player target = Bukkit.getPlayerExact(args[0]);
                if (target == null) { sender.sendMessage("Người chơi không online."); return true; }
                if (!args[1].matches("[1-9]")) { sender.sendMessage("Cảnh giới phải từ 1 đến 9."); return true; }
                int realm = parseRealm(args[1]);
                setRealm(target, realm);
                sender.sendMessage("Đã đặt cảnh giới " + realmName(realm) + " cho " + target.getName());
                return true;
            }
            sender.sendMessage("Lệnh này cần người chơi, ngoại trừ quản trị /canhgioi <player> <1-9>.");
            return true;
        }
        switch (command.getName().toLowerCase(Locale.ROOT)) {
            case "tutien" -> openMenu(p);
            case "kiem" -> {
                if (!getConfig().getBoolean("flight.enabled", true)) { msg(p, "&cNgự kiếm đang tắt."); return true; }
                String sub = args.length == 0 ? "bay" : args[0].toLowerCase(Locale.ROOT);
                if (sub.equals("tocdo")) { msg(p, "&bTốc độ bay cơ bản: &f" + getConfig().getDouble("flight.base-speed", .45)); return true; }
                if (sub.equals("tat")) { p.setFlying(false); p.setAllowFlight(false); msg(p, "&7Đã tắt ngự kiếm."); return true; }
                if (getConfig().getBoolean("flight.require-permission") && !p.hasPermission(getConfig().getString("flight.permission", "kiemxuat.flight"))) {
                    msg(p, "&cBạn chưa mở khóa ngự kiếm."); return true;
                }
                if (souls.containsKey(p.getUniqueId())) { msg(p, "&cHãy thu hồn trước khi ngự kiếm."); return true; }
                boolean active = p.getAllowFlight() && p.isFlying();
                p.setAllowFlight(true); p.setFlying(!active);
                if (!active) { p.setVelocity(p.getVelocity().setY(Math.max(0.15, p.getVelocity().getY()))); p.getWorld().playSound(p.getLocation(), Sound.ITEM_TRIDENT_RIPTIDE_1, .7f, 1.4f); }
                else p.setAllowFlight(false);
                msg(p, active ? "&7Đã tắt ngự kiếm." : "&bNgự kiếm đã kích hoạt. Dùng WASD và phím nhảy/hạ xuống để điều khiển.");
            }
            case "xuathon" -> startSoul(p);
            case "thuhon" -> returnSoul(p, true);
            case "thanthuc" -> scan(p);
            case "canhgioi" -> {
                if (args.length == 0) { msg(p, "&eCảnh giới: &b" + realmName(getRealm(p)) + " &7(" + getRealm(p) + "/9)"); return true; }
                if (!p.hasPermission("kiemxuat.admin")) { msg(p, "&cBạn không có quyền đặt cảnh giới."); return true; }
                if (args.length != 1 || !args[0].matches("[1-9]")) {
                    msg(p, "&cDùng: /canhgioi <1-9> hoặc /canhgioi <người chơi> <1-9> từ console.");
                    return true;
                }
                int r = parseRealm(args[0]); setRealm(p, r); msg(p, "&aĐã đặt cảnh giới: &b" + realmName(r));
            }
        }
        return true;
    }

    private void openMenu(Player p) {
        Inventory inv = Bukkit.createInventory(null, 27, MENU_TITLE);
        inv.setItem(10, item(Material.DIAMOND_SWORD, "&bNgự Kiếm", "&7Bật/tắt bay cơ bản", "&eNhấn để sử dụng"));
        inv.setItem(13, item(Material.ENDER_EYE, "&dXuất Hồn", "&7Hồn thể rời thân xác", "&7Giới hạn theo cảnh giới", "&eNhấn để xuất hồn"));
        inv.setItem(15, item(Material.COMPASS, "&aThần Thức", "&7Quét sinh linh quanh bạn", "&eNhấn để quét"));
        inv.setItem(22, item(Material.NETHER_STAR, "&6Cảnh Giới", "&f" + realmName(getRealm(p)), "&7Cấp " + getRealm(p) + "/9"));
        p.openInventory(inv);
    }
    @EventHandler public void onMenuClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p) || !MENU_TITLE.equals(e.getView().getTitle())) return;
        e.setCancelled(true);
        if (e.getCurrentItem() == null) return;
        switch (e.getRawSlot()) {
            case 10 -> p.performCommand("kiem bay");
            case 13 -> p.performCommand("xuathon");
            case 15 -> p.performCommand("thanthuc");
            case 22 -> p.performCommand("canhgioi");
        }
        p.closeInventory();
    }

    private void startSoul(Player p) {
        if (!getConfig().getBoolean("soul.enabled", true)) { msg(p, "&cXuất hồn đang tắt."); return; }
        if (souls.containsKey(p.getUniqueId())) { msg(p, "&eBạn đã xuất hồn. Dùng /thuhon để trở về."); return; }
        if (p.isInsideVehicle() || p.isFlying() || p.getGameMode() == GameMode.SPECTATOR) { msg(p, "&cKhông thể xuất hồn trong trạng thái hiện tại."); return; }
        Location body = p.getLocation().clone();
        int realm = getRealm(p);
        double distance = numberForRealm("soul.max-distance-by-realm", realm, 12);
        long duration = (long) numberForRealm("soul.max-duration-seconds-by-realm", realm, 8);
        ArmorStand spirit = p.getWorld().spawn(body.clone().add(0, 0.1, 0), ArmorStand.class, a -> {
            a.setInvisible(true); a.setMarker(true); a.setSmall(true); a.setGravity(false); a.setInvulnerable(true);
            a.setCustomName(ChatColor.AQUA + "Hồn thể • " + p.getName()); a.setCustomNameVisible(true);
            a.getEquipment().setHelmet(new ItemStack(Material.SOUL_LANTERN));
        });
        boolean wasInvisible = p.isInvisible();
        boolean wasInvulnerable = p.isInvulnerable();
        boolean wasCollidable = p.isCollidable();
        boolean wasAllowFlight = p.getAllowFlight();
        boolean wasFlying = p.isFlying();
        p.setInvisible(true);
        p.setInvulnerable(true);
        p.setCollidable(false);
        p.setAllowFlight(true);
        p.setFlying(true);
        souls.put(p.getUniqueId(), new SoulState(body, spirit, System.currentTimeMillis() + duration * 1000,
                distance, wasInvisible, wasInvulnerable, wasCollidable, wasAllowFlight, wasFlying));
        msg(p, "&dHồn thể đã xuất khiếu. &7Di chuyển để do thám; /thuhon để trở về. Thời gian: " + duration + " giây.");
    }

    private void tickSouls() {
        for (UUID id : new ArrayList<>(souls.keySet())) {
            Player p = Bukkit.getPlayer(id); SoulState s = souls.get(id);
            if (p == null || s == null) { if (s != null && s.avatar().isValid()) s.avatar().remove(); souls.remove(id); continue; }
            if (!s.avatar().isValid() || System.currentTimeMillis() >= s.expiresAt()) { returnSoul(p, true); continue; }
            if (!p.getWorld().equals(s.body().getWorld()) || p.getLocation().distanceSquared(s.body()) > s.maxDistance() * s.maxDistance()) {
                p.teleport(s.body()); msg(p, "&eĐã chạm giới hạn thần thức."); continue;
            }
            // The avatar marks the player's original body; do not move it with the soul.
            p.getWorld().spawnParticle(Particle.SOUL, p.getLocation().clone().add(0, 0.8, 0), 2, .18, .25, .18, .01);
        }
    }

    private void returnSoul(Player p, boolean announce) {
        if (p == null) return;
        SoulState s = souls.remove(p.getUniqueId());
        if (s == null) { if (announce) msg(p, "&7Bạn chưa xuất hồn."); return; }
        if (s.avatar().isValid()) s.avatar().remove();
        p.teleport(s.body());
        p.setInvisible(s.wasInvisible());
        p.setInvulnerable(s.wasInvulnerable());
        p.setCollidable(s.wasCollidable());
        p.setFlying(false);
        p.setAllowFlight(s.wasAllowFlight());
        if (s.wasFlying() && s.wasAllowFlight()) p.setFlying(true);
        if (announce) { p.getWorld().playSound(p.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, .8f, 1.6f); msg(p, "&aHồn phách đã trở về thân xác."); }
    }

    private void scan(Player p) {
        long now = System.currentTimeMillis(), last = lastScan.getOrDefault(p.getUniqueId(), 0L);
        if (now - last < 1800) { msg(p, "&7Thần thức đang hồi phục."); return; }
        lastScan.put(p.getUniqueId(), now);
        double radius = getConfig().getDouble("soul.scan-radius", 16);
        int limit = getConfig().getInt("soul.scan-limit", 12), count = 0;
        msg(p, "&aThần thức quét trong bán kính &f" + (int) radius + " &ablock:");
        List<Entity> entities = p.getNearbyEntities(radius, radius, radius);
        entities.sort(Comparator.comparingDouble(e -> e.getLocation().distanceSquared(p.getLocation())));
        for (Entity e : entities) {
            if (e instanceof ArmorStand || e instanceof Item || e instanceof ExperienceOrb) continue;
            if (count++ >= limit) break;
            String name = e instanceof LivingEntity le && le.getCustomName() != null ? le.getCustomName() : e.getName();
            msg(p, "&7• &f" + name + " &8— &b" + String.format(Locale.US, "%.1f", e.getLocation().distance(p.getLocation())) + " block");
        }
        if (count == 0) msg(p, "&7Không phát hiện sinh linh nào.");
    }

    @EventHandler public void onMove(PlayerMoveEvent e) {
        SoulState s = souls.get(e.getPlayer().getUniqueId());
        if (s == null) return;
        Player p = e.getPlayer();
        if (e.getTo() != null && (!e.getTo().getWorld().equals(s.body().getWorld()) || e.getTo().distanceSquared(s.body()) > s.maxDistance() * s.maxDistance())) {
            e.setTo(s.body().clone().setDirection(p.getLocation().getDirection()));
            msg(p, "&eBạn đã chạm giới hạn khoảng cách xuất hồn.");
        }
    }
    @EventHandler public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p) || !souls.containsKey(p.getUniqueId())) return;
        e.setCancelled(true);
        if (getConfig().getBoolean("soul.warn-owner-if-damaged", true)) msg(p, "&cThân xác đang xuất hồn được bảo vệ trong bản cơ bản này.");
    }
    @EventHandler public void onQuit(PlayerQuitEvent e) { returnSoul(e.getPlayer(), false); }
    @EventHandler public void onDeath(PlayerDeathEvent e) { returnSoul(e.getEntity(), false); }
    @EventHandler public void onWorldChange(PlayerChangedWorldEvent e) { if (souls.containsKey(e.getPlayer().getUniqueId())) returnSoul(e.getPlayer(), true); }

    private ItemStack item(Material mat, String name, String... lore) {
        ItemStack it = new ItemStack(mat); ItemMeta meta = it.getItemMeta();
        meta.setDisplayName(color(name)); meta.setLore(Arrays.stream(lore).map(this::color).toList()); it.setItemMeta(meta); return it;
    }
    private void msg(CommandSender p, String text) { p.sendMessage(color(getConfig().getString("messages.prefix", "&8[&bTu Tiên&8] ") + text)); }
    private String color(String s) { return ChatColor.translateAlternateColorCodes('&', s); }
    private int getRealm(Player p) { return Math.max(1, Math.min(9, p.getPersistentDataContainer().getOrDefault(realmKey, PersistentDataType.INTEGER, 1))); }
    private void setRealm(Player p, int r) { p.getPersistentDataContainer().set(realmKey, PersistentDataType.INTEGER, Math.max(1, Math.min(9, r))); }
    private int parseRealm(String s) { try { return Math.max(1, Math.min(9, Integer.parseInt(s))); } catch (Exception ex) { return 1; } }
    private String realmName(int r) { List<String> list = getConfig().getStringList("realms"); return r >= 1 && r <= list.size() ? list.get(r - 1) : "Luyện Khí"; }
    private double numberForRealm(String path, int realm, double fallback) { List<?> l = getConfig().getList(path); if (l == null || l.isEmpty()) return fallback; Object v = l.get(Math.min(realm - 1, l.size() - 1)); return v instanceof Number n ? n.doubleValue() : fallback; }

    @Override public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (command.getName().equalsIgnoreCase("kiem") && args.length == 1) return List.of("bay", "tat", "tocdo");
        if (command.getName().equalsIgnoreCase("canhgioi") && args.length == 1) return List.of("1","2","3","4","5","6","7","8","9");
        return Collections.emptyList();
    }
}